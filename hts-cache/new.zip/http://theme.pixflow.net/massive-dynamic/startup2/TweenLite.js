<!DOCTYPE html>
<html lang="en-US" data-theme="massive-dynamic">
<head>
    <meta sidebar-type="" name="post-id" content="" setting-status="general" detail="other" page-url="" />	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
    <meta name="format-detection" content="telephone=no">
    



	<link rel="pingback" href="http://theme.pixflow.net/massive-dynamic/startup2/xmlrpc.php" />

	<!-- Theme Hook -->
    <title>Page not found &#8211; Massive Dynamic Startup Theme</title>
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Massive Dynamic Startup Theme &raquo; Feed" href="http://theme.pixflow.net/massive-dynamic/startup2/feed/" />
<link rel="alternate" type="application/rss+xml" title="Massive Dynamic Startup Theme &raquo; Comments Feed" href="http://theme.pixflow.net/massive-dynamic/startup2/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.2"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-includes/css/dist/block-library/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.5.16' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='go-pricing-styles-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/go_pricing/assets/css/go_pricing_styles.css?ver=3.3.17' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.6.4' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=4.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=4.2.2' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=4.2.2' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/style.css?ver=8' type='text/css' media='all' />
<link rel='stylesheet' id='page-style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/md_cache/.css?ver=8' type='text/css' media='all' />
<link rel='stylesheet' id='plugin-styles-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/css/plugin.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='woo-commerce-styles-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/css/woo-commerce.min.css?ver=8' type='text/css' media='all' />
<link rel='stylesheet' id='px-iconfonts-style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/css/iconfonts.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/css/flexslider.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/css/responsive.min.css?ver=8' type='text/css' media='all' />
<style id='responsive-style-inline-css' type='text/css'>
h1{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:70px;line-height:75px;letter-spacing:0px;}h2{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:60px;line-height:65px;letter-spacing:0px;}h3, h3.wpb_accordion_header,h3.wpb_toggle_header,.woocommerce-loop-product__title{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:50px;line-height:55px;letter-spacing:0px;}h4{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:40px;line-height:45px;letter-spacing:0px;}h5{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:30px;line-height:35px;letter-spacing:0px;}h6{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:20px;line-height:25px;letter-spacing:0px;}p{color:rgb(0,0,0);font-family:Open Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}a{color:rgb(0,0,0);font-family:Open Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}.woocommerce-order-received table.shop_table th{color:rgb(0,0,0);font-family:Open Sans;font-weight:400 !important;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}.layout{padding-top:0px;padding-bottom:0px;width:100%;}main{padding-top:0px;}header .content ul.icons-pack li.icon ,header.top-block .style-style2 .icons-pack .icon.notification-item{display:none;}header { top:22px;}header[class *= "side-" ]{width: 14%;;}header:not(.top-block) .top nav > ul > li .menu-title .icon , header.side-classic .side nav > ul > li > a .menu-title .icon, header.side-classic.standard-mode .style-center nav > ul > li > a .menu-title .icon, .gather-overlay .navigation li a span.icon, header.top-block.header-style1 .navigation > ul > li > a span.icon, header:not(.top-block) .top nav > ul > li .hover-effect .icon {display:none;} header:not(.top-block) .top nav > ul > li .menu-title .title, header.side-classic .side nav > ul > li > a .menu-title .title, header:not(.top-block) .top nav > ul > li .hover-effect .title {display:inline-block;}.activeMenu{ color:rgb(0,90,192) !important;}header a, header .navigation a, header .navigation, .gather-overlay .menu a, header.side-classic div.footer .footer-content .copyright p{ color:rgb(255,255,255);font-family:Poppins;font-weight:500;font-style:normal;font-size:14px;letter-spacing:0px;line-height : 1.5em;}header .icons-pack a{color:rgb(255,255,255)}header .navigation .separator a {background-color:rgba(255,255,255,0.5);;}header .icons-pack .elem-container .title-content{color:rgb(255,255,255);}.top-classic .navigation .menu-separator,.top-logotop .navigation .menu-separator{ background-color:rgb(0,90,192);}.top-classic:not(.header-clone) .style-wireframe .navigation .menu-separator{ background-color:rgb(255,255,255);}header.top-block .icons-pack li .elem-container,header .top .icons-pack .icon span,header.top-block .icons-pack li .title-content .icon,header.top-modern .icons-pack li .title-content .icon,header .icons-pack a{ font-size:18px;}.gather-btn .gather-menu-icon,header .icons-pack a.shopcart .icon-shopcart2,header .icons-pack a.shopcart .icon-shopping-cart{font-size:21px;}header .icons-pack .shopcart-item .number{color:rgb(255,255,255);background-color:rgb(0,90,192);}.layout-container .business{display:none;}header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title , header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title:after{ color:rgb(0,90,192);} .top-classic .style-wireframe .navigation > ul > li:hover .menu-separator{ background-color:rgb(0,90,192);} header.top-classic .icons-pack .icon:hover { color:rgb(0,90,192);}header.top-modern .btn-1b:after { background:rgb(255,255,255);}header.top-modern .btn-1b:active{ background:rgb(255,255,255);}header.top-modern nav > ul> li, header.top-modern .icons-pack li, header.top-modern .first-part{ border-right: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business{ border-bottom: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business, header.top-modern .business a{ color:rgb(255,255,255);}header.side-classic nav > ul > li:hover > a, header.side-classic.standard-mode .icons-holder ul.icons-pack li:hover a, header.side-classic.standard-mode .footer-socials li:hover a, header.side-classic nav > ul > li.has-dropdown:not(.megamenu):hover > a, header.side-classic nav > ul > li:hover > a > .menu-title span, header.side-classic .footer-socials li a .hover, header.side-classic .icons-pack li a .hover, header.side-modern .icons-pack li a span.hover, header.side-modern .nav-modern-button span.hover, header.side-modern .footer-socials span.hover, header.side-classic nav > ul > li.has-dropdown:not(.megamenu) .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li.has-dropdown:not(.megamenu):hover > a .menu-title span{ color:rgb(0,90,192);border-color:rgb(0,90,192);}header.side-classic div.footer ul li.info .footer-content span, header.side-classic .icons-pack li.search .search-form input{ color:rgb(255,255,255);}header.side-classic div.footer ul, header.side-classic div.footer ul li, header.side-classic .icons-holder{ border-color:rgb(255,255,255);}header.side-classic .icons-holder li hr{ background-color:rgb(255,255,255);}header .side .footer .copyright p{ color:rgb(255,255,255);}header .color-overlay, header.side-modern .footer .info .footer-content .copyright, header.side-modern .footer .info .footer-content .footer-socials, header.side-modern .search-form input[type="text"]{background-color: rgba(255,255,255,0);}header:not(.header-clone) > .color-overlay{}.second-header-bg {}header nav.navigation li.megamenu > .dropdown, header nav.navigation li.has-dropdown > .dropdown{ display : table; position: absolute; top:70px;}header nav.navigation li.megamenu > .dropdown > .megamenu-dropdown-overlay, .gather-overlay nav li.megamenu > .dropdown > .megamenu-dropdown-overlay, header nav > ul > li.has-dropdown:not(.megamenu) ul .megamenu-dropdown-overlay{ background-color:rgba(255,255,255,.8);}header nav.navigation > ul > li.megamenu > ul > li > a{ color:rgb(200,200,200);}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > ul.dropdown:not(.side-line), header[class *= "top-"]:not(.right) nav.navigation > ul > li.has-dropdown > ul.dropdown:not(.side-line){border-top:3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, header.top nav.navigation li.megamenu > .dropdown.side-line, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, .gather-overlay nav.navigation li.megamenu > .dropdown.side-line{ border-left: 3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after{ background-color:rgba(0,0,0,0.3);;}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > .dropdown,header[class *= "top-"]:not(.right) nav.navigation li.has-dropdown > .dropdown{left: 0;}header[class *= "top-"] nav .dropdown a, header[class *= "side-"] nav .dropdown a, .gather-overlay nav .dropdown a{ font-size:13px;}.gather-overlay nav.navigation li.megamenu > .dropdown, .gather-overlay nav.navigation li.has-dropdown > .dropdown{ background-color:rgba(255,255,255,.8);display : table; left: 0; position: absolute; top: 150%; }header.left nav.navigation > ul > li.has-dropdown > .dropdown .megamenu-dropdown-overlay, header.side-modern .side.style-style2 nav > ul > li .megamenu-dropdown-overlay, header.side-modern .side.style-style1 nav > ul .megamenu-dropdown-overlay, header.side-modern .style-style1.side nav ul li{ background-color:rgba(255,255,255,.8);}header.side-modern .style-style1.side nav ul li, header.side-modern .style-style1.side nav.navigation > ul > li.has-dropdown .dropdown{ border-color:rgba(0,0,0,0.3);;color:rgb(0,0,0);}header nav.navigation .dropdown a, header.side-modern nav.navigation a, .gather-overlay nav.navigation .dropdown a{ color:rgb(0,0,0);position: relative !important; width: auto !important;}header .top nav > ul > li > ul li:hover > a .menu-title span, header .top nav > ul > li .dropdown a:hover .menu-title span, .gather-overlay nav > ul > li > ul li:hover > a .menu-title span, .gather-overlay nav > ul > li .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li:hover > a .menu-title span, header.side-classic nav > ul > li .dropdown a:hover .menu-title span, header.side-modern .side.style-style2 nav.navigation ul li a:hover{ color:rgba(63,63,63,1);border-color:rgba(63,63,63,1);}header.side-modern .side.style-style1 nav.navigation ul li:hover{ background-color:rgba(63,63,63,1);}.layout-container> .color-overlay,.layout-container> .texture-overlay,.layout-container > .bg-image { display:none; }.layout-container > .color-overlay.image-type,.layout-container> .bg-image { display:none; }.layout-container > .color-overlay.texture-type,.layout-container> .texture-overlay{ display:none; }.layout-container> .color-overlay.color-type {background-color:#FFF;}.layout-container> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.layout-container> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}footer> .color-overlay.color-type { display:none; }footer > .color-overlay.texture-type,footer> .texture-overlay{ display:none; }footer> .bg-image { background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/2017/05/footer-1.jpg);}footer> .bg-image { background-repeat:repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1.0;}footer> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}main .content .color-overlay.color-type { display:none }main .content .color-overlay.color-type { background-color: #FFF;}main .content { padding:0px;}main #content { margin-left: auto; margin-right: auto; }footer {width: 100% ; margin-top:0px; }footer .content{width:85%;}#footer-bottom .social-icons span a,#footer-bottom .go-to-top a,#footer-bottom p{color:rgb(255,255,255)}footer.footer-default .footer-widgets {background-color:rgba(40, 40, 40, 1);overflow: hidden;}footer .widget-area {height:373px;}footer hr.footer-separator{height:0px;background-color:rgba(255,255,255,.1)}footer.footer-default .widget-area.classicStyle.border.boxed div[class*="col-"]{height:253px;}footer.footer-default .widget-area.classicStyle.border.full div[class*="col-"]{height :373px;padding : 45px 30px;}footer.footer-default #footer-bottom{background-color:rgba(53,53,53,0.04);}#footer-bottom{height:149px;}#footer-bottom .social-icons > span:not(.go-to-top){display:inline-flex;}#footer-bottom .copyright{display:block;}#footer-bottom .logo{opacity:1;}#footer-bottom {display:block;}.sidebar.box .widget > .color-overlay.image-type,.sidebar.box .widget> .bg-image { display:none; }.sidebar.box .widget > .color-overlay.texture-type,.sidebar.box .widget> .texture-overlay{ display:none; }.sidebar.box .widget> .color-overlay.color-type {background-color:#FFF;}.sidebar.box .widget> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar.box .widget> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar > .color-overlay.image-type,.sidebar> .bg-image { display:none; }.sidebar > .color-overlay.texture-type,.sidebar> .texture-overlay{ display:none; }.sidebar> .color-overlay.color-type {background-color:#FFF;}.sidebar> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar.box .widget .color-overlay, .sidebar.box .widget .texture-overlay, .sidebar.box .widget .bg-image{ display:none;}.dark-sidebar .widget-contact-info-content, .dark .widget-contact-info-content{ background:url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/img/map-dark.png)no-repeat 10px 15px;}.light-sidebar .widget-contact-info-content, .light .widget-contact-info-content{ background:url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/img/map-light.png)no-repeat 10px 15px;}.layout-container .business { background:rgb(82,82,82);top:0px;height: 36px;}.layout-container .business,.layout-container .business a { color:rgba(255,255,255,1);}header { margin-top: 0 }.box_size{ width:70%}.box_size_container{ width:70%}.widget a, .widget p, .widget span:not(.icon-caret-right)/*:not(.star-rating span)*/{ font-family:Open Sans;}.loop-post-content .post-title:hover{ color:rgba(0,0,0,0.8);;}.woocommerce ul.product_list_widget li span:not(.star-rating span){ font-family:Open Sans;}.notification-center .post .date .day.accent-color, #notification-tabs p.total, #notification-tabs p.total .amount, #notification-tabs .cart_list li .quantity, #notification-tabs .cart_list li .quantity .amount{ color :rgb(181,169,114);}.notification-center span, .notification-center a, .notification-center p, #notification-tabs #result-container .search-title, #notification-tabs #result-container .more-result, #notification-tabs #result-container .item .title, #notification-tabs #search-input, #notification-tabs .cart_list li.empty, .notification-collapse{ font-family :Poppins;}.notification-center .pager .shop, .notification-center #notification-tabs .pager .shop.selected{ display :none; }.notification-center .tabs-container .shop-tab{ opacity : 0; }.portfolio .accent-color, .portfolio .accent-color.more-project, .portfolio-carousel .accent-color.like:hover, .portfolio-carousel .buttons .sharing:hover{ color :rgb(204,162,107)}.portfolio-split .accent-color.like:hover, .portfolio-full .accent-color.like:hover{ background-color :rgb(204,162,107);border-color :rgb(204,162,107);color:#fff; }.portfolio .accent-color.more-project:after{ background-color :rgb(204,162,107)}.portfolio .accent-color.more-project:hover{ color :rgba(204,162,107,0.6);}.portfolio .category span { color :rgba(0,0,0,0.7);}.portfolio .buttons .sharing, .portfolio-carousel .buttons .like{ border-color:rgb(0,0,0);color: rgb(0,0,0); }.portfolio-split .buttons .sharing:hover, .portfolio-full .buttons .sharing:hover{ background-color:rgb(0,0,0);color: #fff; }.md-pixflow-slider .btn-container .shortcode-btn a.button{ font-family:Open Sans;}.md-statistic .timer-holder .timer, .md-counter:not(.md-countbox):not(.md-counter-card) .timer, .img-box-fancy .image-box-fancy-title{ font-family:Poppins;letter-spacing:0px;}.process-panel-main-container .sub-title{ font-family:Poppins;font-weight:400;font-style:normal;letter-spacing:0px;}.error404 .item-setting, body:not(.compose-mode) .item-setting{display: none;}header.top-classic .style-none nav > ul > .item_button{color:rgb(0,0,0);}header.top-classic .style-none nav > ul > .item_button:hover{color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval_outline-style a,header.top-classic .style-none nav > ul > .item_button.rectangle_outline-style a{border-color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval-style a,header.top-classic .style-none nav > ul > .item_button.rectangle-style a{background-color:rgb(255,255,255);}h1{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:70px;line-height:75px;letter-spacing:0px;}h2{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:60px;line-height:65px;letter-spacing:0px;}h3, h3.wpb_accordion_header,h3.wpb_toggle_header,.woocommerce-loop-product__title{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:50px;line-height:55px;letter-spacing:0px;}h4{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:40px;line-height:45px;letter-spacing:0px;}h5{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:30px;line-height:35px;letter-spacing:0px;}h6{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:20px;line-height:25px;letter-spacing:0px;}p{color:rgb(0,0,0);font-family:Open Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}a{color:rgb(0,0,0);font-family:Open Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}.woocommerce-order-received table.shop_table th{color:rgb(0,0,0);font-family:Open Sans;font-weight:400 !important;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}.layout{padding-top:0px;padding-bottom:0px;width:100%;}main{padding-top:0px;}header .content ul.icons-pack li.icon ,header.top-block .style-style2 .icons-pack .icon.notification-item{display:none;}header { top:22px;}header[class *= "side-" ]{width: 14%;;}header:not(.top-block) .top nav > ul > li .menu-title .icon , header.side-classic .side nav > ul > li > a .menu-title .icon, header.side-classic.standard-mode .style-center nav > ul > li > a .menu-title .icon, .gather-overlay .navigation li a span.icon, header.top-block.header-style1 .navigation > ul > li > a span.icon, header:not(.top-block) .top nav > ul > li .hover-effect .icon {display:none;} header:not(.top-block) .top nav > ul > li .menu-title .title, header.side-classic .side nav > ul > li > a .menu-title .title, header:not(.top-block) .top nav > ul > li .hover-effect .title {display:inline-block;}.activeMenu{ color:rgb(0,90,192) !important;}header a, header .navigation a, header .navigation, .gather-overlay .menu a, header.side-classic div.footer .footer-content .copyright p{ color:rgb(255,255,255);font-family:Poppins;font-weight:500;font-style:normal;font-size:14px;letter-spacing:0px;line-height : 1.5em;}header .icons-pack a{color:rgb(255,255,255)}header .navigation .separator a {background-color:rgba(255,255,255,0.5);;}header .icons-pack .elem-container .title-content{color:rgb(255,255,255);}.top-classic .navigation .menu-separator,.top-logotop .navigation .menu-separator{ background-color:rgb(0,90,192);}.top-classic:not(.header-clone) .style-wireframe .navigation .menu-separator{ background-color:rgb(255,255,255);}header.top-block .icons-pack li .elem-container,header .top .icons-pack .icon span,header.top-block .icons-pack li .title-content .icon,header.top-modern .icons-pack li .title-content .icon,header .icons-pack a{ font-size:18px;}.gather-btn .gather-menu-icon,header .icons-pack a.shopcart .icon-shopcart2,header .icons-pack a.shopcart .icon-shopping-cart{font-size:21px;}header .icons-pack .shopcart-item .number{color:rgb(255,255,255);background-color:rgb(0,90,192);}.layout-container .business{display:none;}header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title , header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title:after{ color:rgb(0,90,192);} .top-classic .style-wireframe .navigation > ul > li:hover .menu-separator{ background-color:rgb(0,90,192);} header.top-classic .icons-pack .icon:hover { color:rgb(0,90,192);}header.top-modern .btn-1b:after { background:rgb(255,255,255);}header.top-modern .btn-1b:active{ background:rgb(255,255,255);}header.top-modern nav > ul> li, header.top-modern .icons-pack li, header.top-modern .first-part{ border-right: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business{ border-bottom: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business, header.top-modern .business a{ color:rgb(255,255,255);}header.side-classic nav > ul > li:hover > a, header.side-classic.standard-mode .icons-holder ul.icons-pack li:hover a, header.side-classic.standard-mode .footer-socials li:hover a, header.side-classic nav > ul > li.has-dropdown:not(.megamenu):hover > a, header.side-classic nav > ul > li:hover > a > .menu-title span, header.side-classic .footer-socials li a .hover, header.side-classic .icons-pack li a .hover, header.side-modern .icons-pack li a span.hover, header.side-modern .nav-modern-button span.hover, header.side-modern .footer-socials span.hover, header.side-classic nav > ul > li.has-dropdown:not(.megamenu) .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li.has-dropdown:not(.megamenu):hover > a .menu-title span{ color:rgb(0,90,192);border-color:rgb(0,90,192);}header.side-classic div.footer ul li.info .footer-content span, header.side-classic .icons-pack li.search .search-form input{ color:rgb(255,255,255);}header.side-classic div.footer ul, header.side-classic div.footer ul li, header.side-classic .icons-holder{ border-color:rgb(255,255,255);}header.side-classic .icons-holder li hr{ background-color:rgb(255,255,255);}header .side .footer .copyright p{ color:rgb(255,255,255);}header .color-overlay, header.side-modern .footer .info .footer-content .copyright, header.side-modern .footer .info .footer-content .footer-socials, header.side-modern .search-form input[type="text"]{background-color: rgba(255,255,255,0);}header:not(.header-clone) > .color-overlay{}.second-header-bg {}header nav.navigation li.megamenu > .dropdown, header nav.navigation li.has-dropdown > .dropdown{ display : table; position: absolute; top:70px;}header nav.navigation li.megamenu > .dropdown > .megamenu-dropdown-overlay, .gather-overlay nav li.megamenu > .dropdown > .megamenu-dropdown-overlay, header nav > ul > li.has-dropdown:not(.megamenu) ul .megamenu-dropdown-overlay{ background-color:rgba(255,255,255,.8);}header nav.navigation > ul > li.megamenu > ul > li > a{ color:rgb(200,200,200);}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > ul.dropdown:not(.side-line), header[class *= "top-"]:not(.right) nav.navigation > ul > li.has-dropdown > ul.dropdown:not(.side-line){border-top:3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, header.top nav.navigation li.megamenu > .dropdown.side-line, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, .gather-overlay nav.navigation li.megamenu > .dropdown.side-line{ border-left: 3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after{ background-color:rgba(0,0,0,0.3);;}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > .dropdown,header[class *= "top-"]:not(.right) nav.navigation li.has-dropdown > .dropdown{left: 0;}header[class *= "top-"] nav .dropdown a, header[class *= "side-"] nav .dropdown a, .gather-overlay nav .dropdown a{ font-size:13px;}.gather-overlay nav.navigation li.megamenu > .dropdown, .gather-overlay nav.navigation li.has-dropdown > .dropdown{ background-color:rgba(255,255,255,.8);display : table; left: 0; position: absolute; top: 150%; }header.left nav.navigation > ul > li.has-dropdown > .dropdown .megamenu-dropdown-overlay, header.side-modern .side.style-style2 nav > ul > li .megamenu-dropdown-overlay, header.side-modern .side.style-style1 nav > ul .megamenu-dropdown-overlay, header.side-modern .style-style1.side nav ul li{ background-color:rgba(255,255,255,.8);}header.side-modern .style-style1.side nav ul li, header.side-modern .style-style1.side nav.navigation > ul > li.has-dropdown .dropdown{ border-color:rgba(0,0,0,0.3);;color:rgb(0,0,0);}header nav.navigation .dropdown a, header.side-modern nav.navigation a, .gather-overlay nav.navigation .dropdown a{ color:rgb(0,0,0);position: relative !important; width: auto !important;}header .top nav > ul > li > ul li:hover > a .menu-title span, header .top nav > ul > li .dropdown a:hover .menu-title span, .gather-overlay nav > ul > li > ul li:hover > a .menu-title span, .gather-overlay nav > ul > li .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li:hover > a .menu-title span, header.side-classic nav > ul > li .dropdown a:hover .menu-title span, header.side-modern .side.style-style2 nav.navigation ul li a:hover{ color:rgba(63,63,63,1);border-color:rgba(63,63,63,1);}header.side-modern .side.style-style1 nav.navigation ul li:hover{ background-color:rgba(63,63,63,1);}.layout-container> .color-overlay,.layout-container> .texture-overlay,.layout-container > .bg-image { display:none; }.layout-container > .color-overlay.image-type,.layout-container> .bg-image { display:none; }.layout-container > .color-overlay.texture-type,.layout-container> .texture-overlay{ display:none; }.layout-container> .color-overlay.color-type {background-color:#FFF;}.layout-container> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.layout-container> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}footer> .color-overlay.color-type { display:none; }footer > .color-overlay.texture-type,footer> .texture-overlay{ display:none; }footer> .bg-image { background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/2017/05/footer-1.jpg);}footer> .bg-image { background-repeat:repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1.0;}footer> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}main .content .color-overlay.color-type { display:none }main .content .color-overlay.color-type { background-color: #FFF;}main .content { padding:0px;}main #content { margin-left: auto; margin-right: auto; }footer {width: 100% ; margin-top:0px; }footer .content{width:85%;}#footer-bottom .social-icons span a,#footer-bottom .go-to-top a,#footer-bottom p{color:rgb(255,255,255)}footer.footer-default .footer-widgets {background-color:rgba(40, 40, 40, 1);overflow: hidden;}footer .widget-area {height:373px;}footer hr.footer-separator{height:0px;background-color:rgba(255,255,255,.1)}footer.footer-default .widget-area.classicStyle.border.boxed div[class*="col-"]{height:253px;}footer.footer-default .widget-area.classicStyle.border.full div[class*="col-"]{height :373px;padding : 45px 30px;}footer.footer-default #footer-bottom{background-color:rgba(53,53,53,0.04);}#footer-bottom{height:149px;}#footer-bottom .social-icons > span:not(.go-to-top){display:inline-flex;}#footer-bottom .copyright{display:block;}#footer-bottom .logo{opacity:1;}#footer-bottom {display:block;}.sidebar.box .widget > .color-overlay.image-type,.sidebar.box .widget> .bg-image { display:none; }.sidebar.box .widget > .color-overlay.texture-type,.sidebar.box .widget> .texture-overlay{ display:none; }.sidebar.box .widget> .color-overlay.color-type {background-color:#FFF;}.sidebar.box .widget> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar.box .widget> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar > .color-overlay.image-type,.sidebar> .bg-image { display:none; }.sidebar > .color-overlay.texture-type,.sidebar> .texture-overlay{ display:none; }.sidebar> .color-overlay.color-type {background-color:#FFF;}.sidebar> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar> .texture-overlay { opacity:0.5;background-image: url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar.box .widget .color-overlay, .sidebar.box .widget .texture-overlay, .sidebar.box .widget .bg-image{ display:none;}.dark-sidebar .widget-contact-info-content, .dark .widget-contact-info-content{ background:url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/img/map-dark.png)no-repeat 10px 15px;}.light-sidebar .widget-contact-info-content, .light .widget-contact-info-content{ background:url(http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/img/map-light.png)no-repeat 10px 15px;}.layout-container .business { background:rgb(82,82,82);top:0px;height: 36px;}.layout-container .business,.layout-container .business a { color:rgba(255,255,255,1);}header { margin-top: 0 }.box_size{ width:70%}.box_size_container{ width:70%}.widget a, .widget p, .widget span:not(.icon-caret-right)/*:not(.star-rating span)*/{ font-family:Open Sans;}.loop-post-content .post-title:hover{ color:rgba(0,0,0,0.8);;}.woocommerce ul.product_list_widget li span:not(.star-rating span){ font-family:Open Sans;}.notification-center .post .date .day.accent-color, #notification-tabs p.total, #notification-tabs p.total .amount, #notification-tabs .cart_list li .quantity, #notification-tabs .cart_list li .quantity .amount{ color :rgb(181,169,114);}.notification-center span, .notification-center a, .notification-center p, #notification-tabs #result-container .search-title, #notification-tabs #result-container .more-result, #notification-tabs #result-container .item .title, #notification-tabs #search-input, #notification-tabs .cart_list li.empty, .notification-collapse{ font-family :Poppins;}.notification-center .pager .shop, .notification-center #notification-tabs .pager .shop.selected{ display :none; }.notification-center .tabs-container .shop-tab{ opacity : 0; }.portfolio .accent-color, .portfolio .accent-color.more-project, .portfolio-carousel .accent-color.like:hover, .portfolio-carousel .buttons .sharing:hover{ color :rgb(204,162,107)}.portfolio-split .accent-color.like:hover, .portfolio-full .accent-color.like:hover{ background-color :rgb(204,162,107);border-color :rgb(204,162,107);color:#fff; }.portfolio .accent-color.more-project:after{ background-color :rgb(204,162,107)}.portfolio .accent-color.more-project:hover{ color :rgba(204,162,107,0.6);}.portfolio .category span { color :rgba(0,0,0,0.7);}.portfolio .buttons .sharing, .portfolio-carousel .buttons .like{ border-color:rgb(0,0,0);color: rgb(0,0,0); }.portfolio-split .buttons .sharing:hover, .portfolio-full .buttons .sharing:hover{ background-color:rgb(0,0,0);color: #fff; }.md-pixflow-slider .btn-container .shortcode-btn a.button{ font-family:Open Sans;}.md-statistic .timer-holder .timer, .md-counter:not(.md-countbox):not(.md-counter-card) .timer, .img-box-fancy .image-box-fancy-title{ font-family:Poppins;letter-spacing:0px;}.process-panel-main-container .sub-title{ font-family:Poppins;font-weight:400;font-style:normal;letter-spacing:0px;}.error404 .item-setting, body:not(.compose-mode) .item-setting{display: none;}header.top-classic .style-none nav > ul > .item_button{color:rgb(0,0,0);}header.top-classic .style-none nav > ul > .item_button:hover{color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval_outline-style a,header.top-classic .style-none nav > ul > .item_button.rectangle_outline-style a{border-color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval_outline-style:hover a,header.top-classic .style-none nav > ul > .item_button.rectangle_outline-style:hover a{border-color:rgb(0,100,244);background-color:rgb(0,100,244)}header.top-classic .style-none nav > ul > .item_button.oval-style:hover a,header.top-classic .style-none nav > ul > .item_button.rectangle-style:hover a{background-color:rgb(0,100,244)}@media (max-width:1023px){body:not(.compose-mode) header.custom-background .color-overlay, body.compose-mode.responsive-mode header.custom-background .color-overlay {background-color:#FFFFFF !important;}header.custom-background .navigation-button, header.custom-background .mobile-sidebar, header.custom-background .mobile-shopcart, header.custom-background{color : #000000 !important;}body:not(.compose-mode) .navigation-mobile.custom-background {background-color:#FFFFFF !important;}.navigation-mobile.header-light a, .navigation-mobile.header-light li .arrow, .navigation-mobile.header-light .sub-menu li a {color:#000000 !important;}.navigation-mobile.custom-background li {border-bottom-color:#000000 !important;}}body.massive-rtl{font-family:Open Sans;}
@media (max-width:1025px){.remove-background{padding-top:60px!important;padding-bottom:40px!important}.remove-padding{padding-bottom:0!important}.img-box-slider ul>li,.remove-padding .img-box-slider ul{height:100%;position:relative;max-height:400px!important}}@media (max-width:800px){.remove-background .row-image{background-image:url(http://demo.massivedynamic.co/startup2/wp-content/uploads/2017/04/Massive-Dynamic-2.jpg)!important}}
</style>
<link rel='stylesheet' id='addtoany-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/add-to-any/addtoany.min.css?ver=1.15' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-style-css'  href='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/css/bootstrap.min.css' type='text/css' media='all' />
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript'>
try {}catch(e){console.log("Syntax Error in Custom JS")}
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/add-to-any/addtoany.min.js?ver=1.1'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.6.4'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.6.4'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/massive-dynamic\/startup2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/massive-dynamic\/startup2\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.2.2'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.2.0'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/js/jquery.flexslider-min.js'></script>
<link rel='https://api.w.org/' href='http://theme.pixflow.net/massive-dynamic/startup2/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://theme.pixflow.net/massive-dynamic/startup2/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://theme.pixflow.net/massive-dynamic/startup2/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.2" />
<meta name="generator" content="WooCommerce 4.2.2" />

<script data-cfasync="false">
window.a2a_config=window.a2a_config||{};a2a_config.callbacks=[];a2a_config.overlays=[];a2a_config.templates={};
(function(d,s,a,b){a=d.createElement(s);b=d.getElementsByTagName(s)[0];a.async=1;a.src="https://static.addtoany.com/menu/page.js";b.parentNode.insertBefore(a,b);})(document,"script");
</script>
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 5.4.6.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>


    <style>

        @media (max-width: 600px) and (orientation: portrait) {



            .md-text-alignment-mobile-portrait-right .md-text-content,
            .md-text-alignment-mobile-portrait-right .md-text-title.inline-editor-title,
            .md-text-alignment-mobile-portrait-right .md-text-title,
            .layout .md-text-alignment-mobile-portrait-right .md-text-button{
                text-align: right !important;
            }


            .layout .md-text-alignment-mobile-portrait-right .md-text-title-separator {
                margin-left: auto !important;
                margin-right: 0 !important;
            }


            .md-text-alignment-mobile-portrait-left .md-text-content,
            .md-text-alignment-mobile-portrait-left .md-text-title.inline-editor-title,
            .md-text-alignment-mobile-portrait-left .md-text-title,
            .layout .md-text-alignment-mobile-portrait-left .md-text-button {
                text-align: left !important;
            }

            .layout .md-text-alignment-mobile-portrait-left .md-text-title-separator {
                margin-left: 0 !important;
                margin-right: auto !important;
            }


            .md-text-alignment-mobile-portrait-center .md-text-content,
            .md-text-alignment-mobile-portrait-center .md-text-title.inline-editor-title,
            .md-text-alignment-mobile-portrait-center .md-text-title,
            .layout .md-text-alignment-mobile-portrait-center .md-text-button {
                text-align: center !important;
            }

            .layout .md-text-alignment-mobile-portrait-center .md-text-title-separator {
                margin-left: auto !important;
                margin-right: auto !important;
            }






            .px-mobile-portrait-align-right  {
                display: flex;
                justify-content: flex-end;
            }

            .px-mobile-portrait-align-center  {
                display: flex;
                justify-content: center;
            }

            .px-mobile-portrait-align-left  {
                display: flex;
                justify-content: flex-start;
            }

            .px-mobile-portrait-align-right .px-svg-container,
            .px-mobile-portrait-align-left .px-svg-container{
                margin: 0 !important;
            }


            .layout .icon-box-mobile-portrait-left img.md-icon-box-image {
                float: left !important;
                display: block;
                clear: both;
                margin: 0px auto !important;
            }

            .layout .icon-box-mobile-portrait-center img.md-icon-box-image {
                float: none !important;
                display: block;
                clear: both;
                margin: 15px auto !important;
            }

            .layout .icon-box-mobile-portrait-right img.md-icon-box-image {
                float: right !important;
                display: block;
                clear: both;
                margin: 0px auto !important;
            }

        }


        @media (max-width: 850px) and (orientation: landscape) {

            .md-text-alignment-mobile-landscape-right .md-text-content,
            .md-text-alignment-mobile-landscape-right .md-text-title.inline-editor-title,
            .md-text-alignment-mobile-landscape-right .md-text-title{
                text-align: right !important;
            }


            .layout .md-text-alignment-mobile-landscape-right .md-text-title-separator {
                margin-left: auto !important;
                margin-right: 0 !important;
            }

            .layout .md-text-alignment-mobile-landscape-right .md-text-button {
                text-align: right !important;
            }


            .md-text-alignment-mobile-landscape-left .md-text-content,
            .md-text-alignment-mobile-landscape-left .md-text-title.inline-editor-title,
            .md-text-alignment-mobile-landscape-left .md-text-title{
                text-align: left !important;
            }

            .layout .md-text-alignment-mobile-landscape-left .md-text-title-separator {
                margin-left: 0 !important;
                margin-right: auto !important;
            }

            .layout .md-text-alignment-mobile-landscape-left .md-text-button {
                text-align: left !important;
            }


            .md-text-alignment-mobile-landscape-center .md-text-content,
            .md-text-alignment-mobile-landscape-center .md-text-title.inline-editor-title,
            .md-text-alignment-mobile-landscape-center .md-text-title{
                text-align: center !important;
            }

            .layout .md-text-alignment-mobile-landscape-center .md-text-title-separator {
                margin-left: auto !important;
                margin-right: auto !important;
            }

            .layout .md-text-alignment-mobile-landscape-center .md-text-button {
                text-align: center !important;
            }




            .px-mobile-landscape-align-right  {
                display: flex;
                justify-content: flex-end;
            }

            .px-mobile-landscape-align-center  {
                display: flex;
                justify-content: center;
            }

            .px-mobile-landscape-align-left  {
                display: flex;
                justify-content: flex-start;
            }

            .px-mobile-landscape-align-right .px-svg-container,
            .px-mobile-landscape-align-left .px-svg-container{
                margin: 0 !important;
            }


            .layout .icon-box-mobile-landscape-left img.md-icon-box-image {
                float: left !important;
                display: inline-block;
                clear: none;
                margin: 0px 15px 0 auto !important;
            }

            .layout .icon-box-mobile-landscape-left .iconbox-side-container {
                max-width: 90% !important;
                text-align: left !important;
            }


            .layout .icon-box-mobile-landscape-right img.md-icon-box-image {
                float: right !important;
                display: inline-block;
                clear: none;
                margin: 0px auto 0 15px !important;
            }

            .layout .icon-box-mobile-landscape-right .iconbox-side-container {
                max-width: 90% !important;
                text-align: right !important;
            }

            .layout .icon-box-mobile-landscape-center img.md-icon-box-image {
                float: none !important;
                display: block;
                clear: both;
                margin: 15px auto !important;
            }







        }



        @media (min-width:600px) and (max-width: 1024px) and (orientation: portrait) {

            .md-text-alignment-tablet-portrait-right .md-text-content,
            .md-text-alignment-tablet-portrait-right .md-text-title.inline-editor-title,
            .md-text-alignment-tablet-portrait-right .md-text-title {
                text-align: right !important;
            }


            .layout .md-text-alignment-tablet-portrait-right .md-text-title-separator {
                margin-left: auto !important;
                margin-right: 0 !important;
            }

            .layout .md-text-alignment-tablet-portrait-right .md-text-button {
                text-align: right !important;
            }


            .md-text-alignment-tablet-portrait-left .md-text-content,
            .md-text-alignment-tablet-portrait-left .md-text-title.inline-editor-title,
            .md-text-alignment-tablet-portrait-left .md-text-title{
                text-align: left !important;
            }

            .layout .md-text-alignment-tablet-portrait-left .md-text-title-separator {
                margin-left: 0 !important;
                margin-right: auto !important;
            }

            .layout .md-text-alignment-tablet-portrait-left .md-text-button {
                text-align: left !important;
            }


            .md-text-alignment-tablet-portrait-center .md-text-content,
            .md-text-alignment-tablet-portrait-center .md-text-title.inline-editor-title,
            .md-text-alignment-tablet-portrait-center .md-text-title {
                text-align: center !important;
            }

            .layout .md-text-alignment-tablet-portrait-center .md-text-title-separator {
                margin-left: auto !important;
                margin-right: auto !important;
            }

            .layout .md-text-alignment-tablet-portrait-center .md-text-button {
                text-align: center !important;
            }







            .px-tablet-portrait-align-right  {
                display: flex;
                justify-content: flex-end;
            }

            .px-tablet-portrait-align-center  {
                display: flex;
                justify-content: center;
            }

            .px-tablet-portrait-align-left  {
                display: flex;
                justify-content: flex-start;
            }

            .px-tablet-portrait-align-right .px-svg-container,
            .px-tablet-portrait-align-left .px-svg-container{
                margin: 0 !important;
            }


            .icon-box-tablet-portrait-center .description {
                text-align: center !important;
            }



            .layout .icon-box-tablet-portrait-left img.md-icon-box-image {
                float: left !important;
                display: inline-block;
                clear: none;
                margin: 0px 15px 0 auto !important;
            }

            .layout .icon-box-tablet-portrait-left .iconbox-side-container {
                max-width: 90% !important;
                text-align: left !important;
            }


            .layout .icon-box-tablet-portrait-right img.md-icon-box-image {
                float: right !important;
                display: inline-block;
                clear: none;
                margin: 0 auto 0 15px !important;
            }

            .layout .icon-box-tablet-portrait-right .iconbox-side-container {
                max-width: 90% !important;
                text-align: right !important;
            }

            .layout .icon-box-tablet-portrait-center img.md-icon-box-image {
                float: none !important;
                display: block;
                clear: both;
                margin: 15px auto !important;
            }

        }




        @media (min-width:850px) and (max-width: 1280px) and (orientation: landscape) {

            .md-text-container.md-align-left.md-text-alignment-tablet-landscape-center,
            .md-text-container.md-align-right.md-text-alignment-tablet-landscape-center{
                justify-content: center;
            }


            .md-text-alignment-tablet-landscape-right .md-text-content,
            .md-text-alignment-tablet-landscape-right .md-text-title.inline-editor-title,
            .md-text-alignment-tablet-landscape-right .md-text-title {
                text-align: right !important;
            }


            .layout .md-text-alignment-tablet-landscape-right .md-text-title-separator {
                margin-left: auto !important;
                margin-right: 0 !important;
            }

            .layout .md-text-alignment-tablet-landscape-right .md-text-button {
                text-align: right;
            }


            .md-text-alignment-tablet-landscape-left .md-text-content,
            .md-text-alignment-tablet-landscape-left .md-text-title.inline-editor-title,
            .md-text-alignment-tablet-landscape-left .md-text-title {
                text-align: left !important;
            }

            .layout .md-text-alignment-tablet-landscape-left .md-text-title-separator {
                margin-left: 0 !important;
                margin-right: auto !important;
            }

            .layout .md-text-alignment-tablet-landscape-left .md-text-button {
                text-align: left;
            }


            .md-text-alignment-tablet-landscape-center .md-text-content,
            .md-text-alignment-tablet-landscape-center .md-text-title.inline-editor-title,
            .md-text-alignment-tablet-landscape-center .md-text-title {
                text-align: center !important;
            }

            .layout .md-text-alignment-tablet-landscape-center .md-text-title-separator {
                margin-left: auto !important;
                margin-right: auto !important;
            }

            .layout .md-text-alignment-tablet-landscape-center .md-text-button {
                text-align: center;
            }


            .px-tablet-landscape-align-right {
                display: flex;
                justify-content: flex-end;
            }

            .px-tablet-landscape-align-center {
                display: flex;
                justify-content: center;
            }

            .px-tablet-landscape-align-left {
                display: flex;
                justify-content: flex-start;
            }

            .px-tablet-landscape-align-right .px-svg-container,
            .px-tablet-landscape-align-left .px-svg-container {
                margin: 0 !important;
            }

            .layout .icon-box-tablet-landscape-left img.md-icon-box-image {
                float: left !important;
                display: inline-block;
                clear: none;
                margin: 0px 15px 0 auto !important;
            }

            .layout .icon-box-tablet-landscape-left .iconbox-side-container {
                max-width: 90% !important;
                text-align: left !important;
                margin-left: 0;
            }


            .layout .icon-box-tablet-landscape-right img.md-icon-box-image {
                float: right !important;
                display: inline-block;
                clear: none;
                margin: 0px auto 0 15px !important;
            }

            .layout .icon-box-tablet-landscape-right .iconbox-side-container {
                max-width: 90% !important;
                text-align: right !important;
            }

            .layout .icon-box-tablet-landscape-center img.md-icon-box-image {
                float: none !important;
                display: block;
                clear: both;
                margin: 15px auto !important;
            }

            .layout .icon-box-tablet-landscape-center .iconbox-side-container {
                max-width: 100% !important;
                text-align: center !important;
                width:100%;
            }

            .iconbox-side.icon-box-tablet-landscape-center .icon-container,
            .iconbox-side.icon-box-tablet-landscape-center .iconbox-side-container {
                text-align: center !important;
                float: none;
            }

            .col-sm-8 .md-text-container ,
            .col-sm-7 .md-text-container ,
            .col-sm-6 .md-text-container ,
            .col-sm-5 .md-text-container,
            .col-sm-3 .md-text-container{
                max-width: 96%;
            }

        }





        @media screen
        and (min-device-width: 1024px)
        and (max-device-width: 1280px) {
            .layout-container .layout .sectionOverlay .box_size_container {
                width: 96% !important;
            }

            .col-sm-8 .md-text-container ,
            .col-sm-7 .md-text-container ,
            .col-sm-6 .md-text-container ,
            .col-sm-5 .md-text-container,
            .col-sm-3 .md-text-container{
                max-width: 96%;
            }


        }



        @media screen
        and (min-device-width: 1281px)
        and (max-device-width: 1680px) {
            .layout-container .layout .sectionOverlay .box_size_container,
            .layout-container .layout .sectionOverlay.box_size {
                width: 80% !important;
            }


        }




















    </style>


<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>	<!-- Custom CSS -->
</head>

<body class="error404 theme-massive-dynamic woocommerce-no-js no-js px-header-top  classic wpb-js-composer js-comp-ver-6.2.0 vc_responsive" >

    <div class="layout-container" id="layoutcontainer">
        <div class="color-overlay color-type"></div>
        <div class="color-overlay texture-type"></div>
        <div class="color-overlay image-type"></div>
        <div class="texture-overlay"></div>
        <div class="bg-image"></div>
    
    <div class="layout">
                <!--End Header-->    <!-- Start of Wrap -->
    <div class="wrap right " style="" >



    <!-- Business Bar  -->
    <div class="business content visible-desktop hidden-tablet business-off" style="width:98%;">
        <div class=" clearfix">
            <div class="info-container">
                <span class="item address">
                    <span class="icon icon-location"></span>
                    <span class="address-content">Your address will show here</span>
                </span>
                <span class="item tel">
                    <a href="tel:+12 34 56 78" title="Call +12 34 56 78">
                        <span class="icon icon-phone"></span>
                        <span class="tel-content">+12 34 56 78</span>
                    </a>
                </span>
                <span class="item email">
                    <a href="mailto:email@example.com" title="Send an email to email@example.com">
                        <span class="icon icon-Mail"></span>
                        <span class="email-content">email@example.com</span>
                    </a>
                </span>
            </div>
            <div class="social icon">
                                        <span data-social="facebook"><a href="#" target="_blank"><span class="icon-facebook2"></span></a></span>
                                            <span data-social="twitter"><a href="#" target="_blank"><span class="icon-twitter5"></span></a></span>
                                            <span data-social="youtube"><a href="#" target="_blank"><span class="icon-youtube2"></span></a></span>
                                </div>
        </div>
    </div>
<!-- header -->
<header style="width: 98%; height:70px;max-height:70px;" class="top-classic header-style3 top header-light logo-dark " data-width="98">
    <div class="color-overlay"></div>
    <div class="texture-overlay"></div>
    <div class="bg-image"></div>

    <div class="content top style-none" style="width:100%;">
        <a class="logo  item-left" style="width: 8.1%;" data-logoStyle="light"><img class="logo-img" data-home-url="http://theme.pixflow.net/massive-dynamic/startup2/" data-light-url="http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/2017/08/light-logo.png" data-dark-url="http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/2017/05/dark-logo-1.png" src="http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/2017/08/light-logo.png"/></a>
                <nav class='navigation hidden-tablet hidden-phone item-right' style='width: 91.2%;'>
                    <ul id="menu-main-menu" class="clearfix"><li id="menu_item-191" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#intro-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">EXPLORE</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu_item-192" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#about-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">CAMPAIGN</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu_item-227" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#donate-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">DONATE</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu_item-193" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#subscribe-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">JOIN US</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu_item-226" class="menu-item menu-item-type-custom menu-item-object-custom item_button rectangle-style "><a target="_blank" href="https://www.kickstarter.com/projects/fowers/hardback-the-pre-quill-to-paperback?ref=home_potd"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">GET THE APP</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li>    <!--Add someting to navigation like search box-->
    </ul>                </nav>
                    <div class="pixflow-heder-icon-pack">
        
        <a class="navigation-button hidden-desktop visible-tablet" href="#">
            <span class="icon-gathermenu"></span>
        </a>

                                    <a class="mobile-shopcart hidden-desktop visible-tablet" href="http://theme.pixflow.net/massive-dynamic/startup2"><span class="icon-shopcart"></span></a>
            
                </div>
    </div>

</header>
<nav class="navigation-mobile header-light ">
    <ul id="menu-main-menu-1" class="menu"><li id="menu-item-mobile191" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#intro-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">EXPLORE</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile192" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#about-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">CAMPAIGN</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile227" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#donate-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">DONATE</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile193" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://theme.pixflow.net/massive-dynamic/startup2/#subscribe-section"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">JOIN US</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile226" class="menu-item menu-item-type-custom menu-item-object-custom item_button rectangle-style "><a target="_blank" href="https://www.kickstarter.com/projects/fowers/hardback-the-pre-quill-to-paperback?ref=home_potd"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">GET THE APP</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li></ul><div class="search-form">
    <form action="http://theme.pixflow.net/massive-dynamic/startup2/">
        <fieldset>
            <input type="text" name="s" placeholder="Search..." value="">
            <input type="submit" value="">
        </fieldset>
    </form>
</div></nav>

                <!-- Start of Main -->
                <main class="clearfix  " style="padding-top:0px; width:100%;">
                                    
        
            <!-- Start of Main content -->
            <div id="content" class="content " style="padding: 0% ;" >
                <div class="color-overlay color-type"></div>
                                            <div class="not-found-page">

                            <div class="image"></div>

                            <strong>404</strong>

                            <p>page is not available</p>

                        </div>
                                    </div>
            <!-- End of Main content -->

            
        </main>
        <!-- End of Main -->

        
<footer id="footer-default-id" class="footer-default " data-footer-status="on" data-width="100">
    <div class="color-overlay texture-type"></div>
    <div class="color-overlay image-type"></div>
    <div class="texture-overlay"></div>
    <div class="bg-image"></div>
            <div class="content-holder">

            <hr class="footer-separator">
    <div id="footer-bottom">
        <div class="linear content">
            <div class="logo"><img src="http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/2017/08/light-logo.png" /></div><div class="social-icons  footer-spacer"><span data-social="facebook"><a href="#" target="_blank"><span class="icon-facebook2"></span></a></span><span data-social="twitter"><a href="#" target="_blank"><span class="icon-twitter5"></span></a></span><span data-social="youtube"><a href="#" target="_blank"><span class="icon-youtube2"></span></a></span></div><div class="copyright footer-spacer"><p>Copyright - Made with Massive Dynamic</p></div>        </div>
    </div>
    </footer>


    </div>
    <!-- End of Wrap -->

    <div class="clearfix"></div>
<!--end of layout element-->
</div>
<!-- end of layout container -->
</div>

<!-- Go to top button -->

    <div class="go-to-top dark md-hidden"></div>
    <!-- Theme Hook -->


	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<link rel='stylesheet' id='vc_google_text_fonts-css'  href='//fonts.googleapis.com/css?family=Poppins%3A400%2C500%2C700%7COpen+Sans%3A400&#038;ver=5.4.2' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-admin\/admin-ajax.php","nonce":"1db0242323","uniqueSettings":"[\"site_width\",\"site_top\",\"site_bg\",\"site_bg_type\",\"site_bg_color_type\",\"site_bg_solid_color\",\"site_bg_gradient_orientation\",\"site_bg_gradient_color1\",\"site_bg_gradient_color2\",\"site_bg_image_image\",\"site_bg_image_repeat\",\"site_bg_image_attach\",\"site_bg_image_position\",\"site_bg_image_size\",\"site_bg_image_opacity\",\"site_bg_image_overlay\",\"site_bg_image_overlay_type\",\"site_bg_image_solid_overlay\",\"site_bg_overlay_gradient_orientation\",\"site_bg_overlay_gradient_color1\",\"site_bg_overlay_gradient_color2\",\"site_bg_texture\",\"site_bg_texture_opacity\",\"site_bg_texture_overlay\",\"site_bg_texture_solid_overlay\",\"header_position\",\"header_top_position\",\"header_theme\",\"header_side_theme\",\"logotop_logoSpace\",\"classic_style\",\"block_style\",\"gather_style\",\"header_side_align\",\"header_side_footer\",\"header_styles\",\"show_up_after\",\"show_up_style\",\"header_top_width\",\"header-top-height\",\"header-side-width\",\"header-content\",\"menu_item_style\",\"header_items_order\",\"nav_color\",\"nav_hover_color\",\"header_bg_color_type\",\"header_bg_solid_color\",\"header_bg_gradient_orientation\",\"header_bg_gradient_color1\",\"header_bg_gradient_color2\",\"logo_style\",\"header_border_enable\",\"nav_color_second\",\"nav_hover_color_second\",\"header_bg_color_type_second\",\"header_bg_solid_color_second\",\"header_bg_gradient_second_orientation\",\"header_bg_gradient_second_color1\",\"header_bg_gradient_second_color2\",\"logo_style_second\",\"popup_menu\",\"popup_menu_color\",\"overlay_bg\",\"header_side_image_image\",\"header_side_image_repeat\",\"header_side_image_position\",\"header_side_image_size\",\"menu_button_style\",\"button_bg_color\",\"button_text_color\",\"button_hover_text_color\",\"button_hover_bg_color\",\"dropdown_bg_solid_color\",\"dropdown_heading_solid_color\",\"dropdown_fg_solid_color\",\"dropdown_fg_hover_color\",\"businessBar_enable\",\"businessBar_style\",\"businessBar_social\",\"businessBar_content_color\",\"businessBar_bg_color\",\"businessBar_address\",\"businessBar_tel\",\"businessBar_email\",\"nav_name\",\"nav_size\",\"nav_weight\",\"nav_letterSpace\",\"nav_style\",\"main-width\",\"mainC-width\",\"main-top\",\"mainC-padding\",\"main_bg\",\"main_bg_color_type\",\"main_bg_solid_color\",\"main_bg_gradient_orientation\",\"main_bg_gradient_color1\",\"main_bg_gradient_color2\",\"footer_widgets_styles\",\"footer_widget_area_height\",\"footer_bottom_area_height\",\"footer-width\",\"footerC-width\",\"footer-marginT\",\"footer-marginB\",\"footer_widgets_order\",\"footer_widget_area_columns_status\",\"footer_widget_area_columns\",\"footer_bottom_items_layout\",\"footer_copyright_text\",\"footer_switcher\",\"footer_logo\",\"footer_copyright\",\"footer_social\",\"footer_logo_skin\",\"footer_logo_opacity\",\"footer_widget_area_skin\",\"footer_parallax\",\"footer_widget_area_bg_color_rgba\",\"copyright_separator\",\"copyright_color\",\"footer_bottom_area_bg_color_rgba\",\"footer_bg\",\"footer_bg_type\",\"footer_bg_image_image\",\"footer_bg_image_repeat\",\"footer_bg_image_attach\",\"footer_bg_image_position\",\"footer_bg_image_size\",\"footer_bg_image_opacity\",\"footer_bg_image_overlay\",\"footer_bg_image_overlay_type\",\"footer_bg_image_solid_overlay\",\"footer_bg_overlay_gradient_orientation\",\"footer_bg_overlay_gradient_color1\",\"footer_bg_overlay_gradient_color2\",\"footer_bg_texture\",\"footer_bg_texture_opacity\",\"footer_bg_texture_overlay\",\"footer_bg_texture_solid_overlay\",\"go_to_top_status\",\"footer_section_gototop_skin\",\"go_to_top_show\",\"sidebar-switch\",\"sidebar-position\",\"sidebar-width\",\"sidebar-skin\",\"sidebar-style\",\"sidebar-align\",\"sidebar-shadow-color\",\"page_sidebar_bg\",\"page_sidebar_bg_type\",\"page_sidebar_bg_color_type\",\"page_sidebar_bg_solid_color\",\"page_sidebar_bg_gradient_orientation\",\"page_sidebar_bg_gradient_color1\",\"page_sidebar_bg_gradient_color2\",\"page_sidebar_bg_image_image\",\"page_sidebar_bg_image_repeat\",\"page_sidebar_bg_image_attach\",\"page_sidebar_bg_image_position\",\"page_sidebar_bg_image_size\",\"page_sidebar_bg_image_opacity\",\"page_sidebar_bg_image_overlay\",\"page_sidebar_bg_image_overlay_type\",\"page_sidebar_bg_image_solid_overlay\",\"page_sidebar_bg_overlay_gradient_orientation\",\"page_sidebar_bg_overlay_gradient_color1\",\"page_sidebar_bg_overlay_gradient_color2\",\"page_sidebar_bg_texture\",\"page_sidebar_bg_texture_opacity\",\"page_sidebar_bg_texture_overlay\",\"page_sidebar_bg_texture_solid_overlay\",\"sidebar-switch-single\",\"sidebar-position-single\",\"sidebar-width-single\",\"sidebar-skin-single\",\"sidebar-style-single\",\"sidebar-align-single\",\"sidebar-shadow-color-single\",\"single_sidebar_bg\",\"single_sidebar_bg_type\",\"single_sidebar_bg_color_type\",\"single_sidebar_bg_solid_color\",\"single_sidebar_bg_gradient_orientation\",\"single_sidebar_bg_gradient_color1\",\"single_sidebar_bg_gradient_color2\",\"single_sidebar_bg_image_image\",\"single_sidebar_bg_image_repeat\",\"single_sidebar_bg_image_attach\",\"single_sidebar_bg_image_position\",\"single_sidebar_bg_image_size\",\"single_sidebar_bg_image_opacity\",\"single_sidebar_bg_image_overlay\",\"single_sidebar_bg_image_overlay_type\",\"single_sidebar_bg_image_solid_overlay\",\"single_sidebar_bg_overlay_gradient_orientation\",\"single_sidebar_bg_overlay_gradient_color1\",\"single_sidebar_bg_overlay_gradient_color2\",\"single_sidebar_bg_texture\",\"single_sidebar_bg_texture_opacity\",\"single_sidebar_bg_texture_overlay\",\"single_sidebar_bg_texture_solid_overlay\",\"sidebar-switch-shop\",\"sidebar-position-shop\",\"sidebar-width-shop\",\"sidebar-skin-shop\",\"sidebar-style-shop\",\"sidebar-align-shop\",\"sidebar-shadow-color-shop\"]"};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/assets/script/unique-setting.min.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-admin\/admin-ajax.php","nonce":"1db0242323"};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/assets/script/post-like.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2.1'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/go_pricing/assets/js/go_pricing_scripts.js?ver=3.3.17'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/massive-dynamic\/startup2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/massive-dynamic\/startup2\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.2.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/massive-dynamic\/startup2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/massive-dynamic\/startup2\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_a79e6edc1a0489e1359b516036fefb8f","fragment_name":"wc_fragments_a79e6edc1a0489e1359b516036fefb8f","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.2.2'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/js/plugins.min.js'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/lib/assets/script/jquery.nicescroll.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-admin\/admin-ajax.php","nonce":"1db0242323"};
var themeOptionValues = {"site_bg_image_attach":"fixed","headerBgColorType":"solid","navColor":"rgb(255,255,255)","navHoverColor":"rgb(0,90,192)","navColorSecond":"rgb(35,35,35)","navHoverColorSecond":"rgb(0,90,192)","headerBgGradientColor1":"rgba(255,255,255,1)","headerBgGradientColor2":"rgba(255,255,255,.5)","headerBgGradientOrientation":"vertical","headerBgColorTypeSecond":"solid","headerBgGradientSecondColor1":"rgba(255,255,255,1)","headerBgGradientSecondColor2":"rgba(255,255,255,.5)","headerBgGradientSecondOrientation":"vertical","headerBgSolidColorSecond":"rgb(255,255,255)","headerBgSolidColor":"rgba(255,255,255,0)","businessBarEnable":"","sidebar_style":"none","page_sidebar_bg_image_position":"center-top","sidebar_style_shop":"none","shop_sidebar_bg_image_position":"center-top","sidebar_style_single":"none","single_sidebar_bg_image_position":"center-top","sidebar_style_blog":"none","blog_sidebar_bg_image_position":"center-top","showUpAfter":"800","showUpStyle":"fade_in","siteTop":"0","footerWidgetAreaSkin":"light","headerTopWidth":"98","layoutWidth":"100","lightLogo":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-content\/uploads\/sites\/5\/2017\/08\/light-logo.png","darkLogo":"http:\/\/theme.pixflow.net\/massive-dynamic\/startup2\/wp-content\/uploads\/sites\/5\/2017\/05\/dark-logo-1.png","logoStyle":"light","logoStyleSecond":"dark","activeNotificationTab":"posts","goToTopShow":"600","loadingType":"light","leaveMsg":"You are about to leave this page and you haven't saved changes yet, would you like to save changes before leaving?","unsaved":"Unsaved Changes!","save_leave":"Save & Leave","mailchimpNotInstalled":"MailChimp for Wordpress is not installed.","search":"Search...","payment_methods":"PAYMENT METHOD","loadingText":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/js/custom.min.js?ver=8'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/uploads/sites/5/md_cache/.js?ver=8'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-content/themes/massive-dynamic/assets/js/smooth_scroll.min.js'></script>
<script type='text/javascript' src='http://theme.pixflow.net/massive-dynamic/startup2/wp-includes/js/wp-embed.min.js?ver=5.4.2'></script>

</body>
</html>